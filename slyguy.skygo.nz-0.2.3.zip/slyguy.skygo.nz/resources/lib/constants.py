HEADERS = {
    'User-Agent': 'Mozilla/5.0 (CrKey armv7l 1.5.16041) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36 sky-android (ver=1.0)',
    'X-Forwarded-For': '202.89.4.222',
}

CLIENT_ID = 'dXhXjmK9G90mOX3B02R1kV7gsC4bp8yx'
GRAPH_URL = 'https://api.skyone.co.nz/exp/graph'
EPG_URL = 'https://i.mjh.nz/SkyGo/epg.xml.gz'
