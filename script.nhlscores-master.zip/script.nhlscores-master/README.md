[![GitHub release](https://img.shields.io/github/release/eracknaphobia/script.nhlscores.svg)](https://github.com/eracknaphobia/script.nhlscores/releases)
![License](https://img.shields.io/badge/license-GPL%20(%3E%3D%202)-orange)
[![Contributors](https://img.shields.io/github/contributors/eracknaphobia/script.nhlscores.svg)](https://github.com/eracknaphobia/script.nhlscores/graphs/contributors)

Live scoring and game updates through kodi
