from resources.lib.scores import *

scores = Scores()
scores.service()