# CBC Sports KodiPlugin Matrix version
An addon for Kodi (XBMC) for Live Events, Replays, and Highlights from CBC Sports

Features:
Get the latest headlines, opinion, and video from CBC Sports.  Watch live events, replays, and highlights.  Region blocked for Canada only.

<img src="resources/icon.png" width="40%">