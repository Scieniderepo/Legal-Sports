import sys
from resources.lib import addon

if __name__ == "__ main__":
  addon.run(sys.argv)
