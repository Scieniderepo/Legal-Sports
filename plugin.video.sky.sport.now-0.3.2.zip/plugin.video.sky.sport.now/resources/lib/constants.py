HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36',
}

API_URL = 'https://www.skysportnow.co.nz{}'
WIDEVINE_URL = 'https://shield-twoproxy.imggaming.com/proxy'
THUMB_URL = 'https://esliondsdoc.akamaized.net/mt/skyfanpass_v2/thumbs/{}'
SCHEDULE_URL = 'https://esliondsdoc.akamaized.net/mt/skyfanpass_v2/epg/{date}.json'
EPG_URL = 'https://i.mjh.nz/SkySportNow/epg.xml.gz'

MEDIA_CHANNEL = 'channel'
MEDIA_VIDEO = 'video'
