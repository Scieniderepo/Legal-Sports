# -*- coding: utf-8 -*-

import sys

from resources.lib.startup import run

run(sys.argv)
