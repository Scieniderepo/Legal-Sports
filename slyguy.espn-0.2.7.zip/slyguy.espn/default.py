import sys

from resources.lib.plugin import plugin

plugin.dispatch(sys.argv[2])